/* ============================================
   ROTEM GOTLIEB — PORTFOLIO
   v2: Name intro + animations + interactions
   ============================================ */

(function () {
  'use strict';

  var transitionOverlay = document.querySelector('.page-transition');
  var nameIntro = document.getElementById('nameIntro');
  var isHomepage = !!nameIntro;
  var introAlreadyShown = sessionStorage.getItem('introShown');

  /* ---- INTRO ANIMATION (homepage, first visit only) ---- */
  if (isHomepage && !introAlreadyShown) {
    document.body.classList.add('intro-active');

    window.addEventListener('load', function () {
      // Remove page transition immediately so intro is visible
      if (transitionOverlay) transitionOverlay.classList.remove('active');

      // Let the character animations play (~1.4s for all chars),
      // then hold for a beat, then fade out
      setTimeout(function () {
        nameIntro.classList.add('fade-out');
        document.body.classList.remove('intro-active');
        sessionStorage.setItem('introShown', 'true');

        // Start page content animations after intro exits
        setTimeout(function () {
          triggerLoadAnimations();
        }, 500);
      }, 2000); // Total intro visible: ~2s
    });

  } else {
    // Non-homepage or return visit: skip intro
    if (nameIntro) nameIntro.style.display = 'none';

    window.addEventListener('load', function () {
      if (transitionOverlay) transitionOverlay.classList.remove('active');
      triggerLoadAnimations();
    });
  }


  /* ---- PAGE TRANSITIONS (internal links) ---- */
  document.addEventListener('click', function (e) {
    var link = e.target.closest('a[href]');
    if (!link) return;
    var href = link.getAttribute('href');
    if (!href || href.startsWith('http') || href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('tel:')) return;

    e.preventDefault();
    if (transitionOverlay) transitionOverlay.classList.add('active');
    setTimeout(function () { window.location.href = href; }, 200);
  });


  /* ---- STAGGERED LOAD ANIMATION ---- */
  function triggerLoadAnimations() {
    var els = document.querySelectorAll('.fade-in');
    var baseDelay = 0;

    els.forEach(function (el, i) {
      var d = baseDelay + (i * 150); // 150ms stagger between elements
      setTimeout(function () { el.classList.add('visible'); }, d);
    });
  }


  /* ---- SCROLL REVEAL (IntersectionObserver) ---- */
  var revealEls = document.querySelectorAll('.reveal');
  if (revealEls.length > 0) {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.1,
      rootMargin: '0px 0px -40px 0px'
    });

    revealEls.forEach(function (el) { observer.observe(el); });
  }


  /* ---- NAV SCROLL EFFECT ---- */
  var navEl = document.querySelector('nav');
  if (navEl) {
    window.addEventListener('scroll', function () {
      if (window.scrollY > 50) navEl.classList.add('scrolled');
      else navEl.classList.remove('scrolled');
    }, { passive: true });
  }


  /* ---- CUSTOM CURSOR (desktop only) ---- */
  if (window.matchMedia('(pointer: fine)').matches) {
    var cursor = document.createElement('div');
    cursor.classList.add('custom-cursor');
    document.body.appendChild(cursor);
    document.body.classList.add('cursor-active');

    var mouseX = 0, mouseY = 0, cursorX = 0, cursorY = 0;
    var smoothing = 0.15;

    document.addEventListener('mousemove', function (e) {
      mouseX = e.clientX;
      mouseY = e.clientY;
    });

    (function animate() {
      cursorX += (mouseX - cursorX) * smoothing;
      cursorY += (mouseY - cursorY) * smoothing;
      cursor.style.transform = 'translate(' + cursorX + 'px, ' + cursorY + 'px)';
      requestAnimationFrame(animate);
    })();

    var hoverTargets = 'a, button, .bento-card, .other-work-card';
    document.addEventListener('mouseover', function (e) {
      if (e.target.closest(hoverTargets)) cursor.classList.add('cursor-hover');
    });
    document.addEventListener('mouseout', function (e) {
      if (e.target.closest(hoverTargets)) cursor.classList.remove('cursor-hover');
    });
  }

})();
